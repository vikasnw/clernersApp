import { Component } from '@angular/core';
import { NavController,ToastController } from 'ionic-angular';
import { MyAccount } from '../my-account/my-account';

/*
  Generated class for the ChangePassword page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-change-password',
  templateUrl: 'change-password.html'
})
export class ChangePassword {

  constructor(public navCtrl: NavController,public toastCtrl: ToastController) {}

  ionViewDidLoad() {
    console.log('Hello ChangePassword Page');
  }

  /**
   * update user password and redirect to my account page
   */
  updatePassword(){

    let toast = this.toastCtrl.create({
      message: 'Password was successfully updated',
      duration: 3000,
      position: 'bottom'
    });

    toast.onDidDismiss(() => {
      this.navCtrl.setRoot(MyAccount);
    });
    toast.present();
  }

  /**
   * back to my account page
   */
  goBack(){
    this.navCtrl.setRoot(MyAccount);
  }

}
