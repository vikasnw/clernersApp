import { Component } from '@angular/core';
import { NavController,ActionSheetController,ToastController } from 'ionic-angular';
import {Camera} from 'ionic-native';
import { ChangePassword } from '../change-password/change-password';

/*
  Generated class for the MyAccount page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-my-account',
  templateUrl: 'my-account.html'
})
export class MyAccount {

  companyLogo: string;

  constructor(public navCtrl: NavController, public actionSheetCtrl: ActionSheetController,public toastCtrl: ToastController) {
    this.companyLogo = 'assets/images/vik.jpg';
  }

  /**
   * event fire when screen show
   */
  ionViewDidLoad() {
    console.log('Hello MyAccount Page');
  }

  /**
   * action for change company logo
   */
  changeCompanyLogo() {
    let actionSheet = this.actionSheetCtrl.create({
      title: 'Change Photo',
      buttons: [
        {
          text: 'Take a photo',
          role: 'takephoto',
          handler: () => {
            this.takeCompanyLogo();
          }
        },
        {
          text: 'Choose from library',
          role: 'choosephoto',
          handler: () => {
            console.log('Open Mobile Library');
          }
        },
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        }
      ]
    });

    actionSheet.present();

  }

  /**
   * open camera on click change logo-> take new photo
   */
  takeCompanyLogo(){
    Camera.getPicture({
      quality : 95,
      destinationType: Camera.DestinationType.DATA_URL,
      sourceType : Camera.PictureSourceType.CAMERA,
      allowEdit : true,
      encodingType: Camera.EncodingType.PNG,
      targetWidth: 500,
      targetHeight: 500,
      saveToPhotoAlbum: true
    }).then((imageData) => {
      // imageData is a base64 encoded string
      this.companyLogo = "data:image/jpeg;base64," + imageData;
      /*update user photo in db and upload also*/
    }, (err) => {
      console.log(err);
    });
  }

  /**
   * update user profile data
   */
  updateProfile(){

    let toast = this.toastCtrl.create({
      message: 'Profile was successfully updated',
      duration: 3000,
      position: 'bottom'
    });

    toast.present();
  }

  /**
   * redirect to reset password
   */
  resetPassword(){
    this.navCtrl.setRoot(ChangePassword);
  }
}
